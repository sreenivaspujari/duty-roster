import { ShiftType, SHIFT_COLORS } from '@/types/roster';
import { cn } from '@/lib/utils';

interface ShiftBadgeProps {
  shift: ShiftType;
  onClick?: () => void;
  size?: 'sm' | 'md';
}

export function ShiftBadge({ shift, onClick, size = 'md' }: ShiftBadgeProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-full font-medium transition-all duration-150',
        'hover:scale-105 active:scale-95',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
        SHIFT_COLORS[shift],
        size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-4 py-1.5 text-sm',
        onClick && 'cursor-pointer'
      )}
    >
      {shift}
    </button>
  );
}
