export type ShiftType = 'Morning' | 'Afternoon' | 'Night' | 'Off';

export interface Member {
  id: string;
  name: string;
  role: string;
}

export interface ShiftAssignment {
  memberId: string;
  day: number; // 0-6 (Mon-Sun)
  shift: ShiftType;
}

export const SHIFT_ORDER: ShiftType[] = ['Morning', 'Afternoon', 'Night', 'Off'];

export const SHIFT_COLORS: Record<ShiftType, string> = {
  Morning: 'bg-amber-400 text-amber-950',
  Afternoon: 'bg-sky-500 text-white',
  Night: 'bg-emerald-500 text-white',
  Off: 'bg-muted text-muted-foreground',
};
