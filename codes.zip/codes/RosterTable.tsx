import { format, isWeekend } from 'date-fns';
import { Trash2 } from 'lucide-react';
import { Member, ShiftType } from '@/types/roster';
import { ShiftBadge } from './ShiftBadge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface RosterTableProps {
  members: Member[];
  days: Date[];
  getShift: (memberId: string, day: number) => ShiftType;
  onCycleShift: (memberId: string, day: number) => void;
  onRemoveMember: (id: string) => void;
}

export function RosterTable({ members, days, getShift, onCycleShift, onRemoveMember }: RosterTableProps) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-sm">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wider text-muted-foreground w-[180px]">Member</th>
            {days.map((day, i) => (
              <th
                key={i}
                className={cn(
                  'px-3 py-3 text-center font-semibold text-xs uppercase tracking-wider min-w-[100px]',
                  isWeekend(day) ? 'text-accent' : 'text-muted-foreground'
                )}
              >
                <div>{format(day, 'EEE')}</div>
                <div className="text-sm font-bold">{format(day, 'd MMM')}</div>
              </th>
            ))}
            <th className="px-3 py-3 text-center font-semibold text-xs uppercase tracking-wider text-muted-foreground w-[60px]">Action</th>
          </tr>
        </thead>
        <tbody>
          {members.map(member => (
            <tr key={member.id} className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors">
              <td className="px-4 py-3">
                <div className="font-semibold text-foreground">{member.name}</div>
                <div className="text-xs text-muted-foreground">{member.role}</div>
              </td>
              {days.map((_, dayIdx) => (
                <td key={dayIdx} className="px-3 py-3 text-center">
                  <ShiftBadge
                    shift={getShift(member.id, dayIdx)}
                    onClick={() => onCycleShift(member.id, dayIdx)}
                  />
                </td>
              ))}
              <td className="px-3 py-3 text-center">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  onClick={() => onRemoveMember(member.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
