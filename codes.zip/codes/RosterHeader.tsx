import { format } from 'date-fns';
import { ChevronLeft, ChevronRight, Sparkles, UserPlus, Share2, Printer, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RosterHeaderProps {
  weekStart: Date;
  memberCount: number;
  onPrev: () => void;
  onNext: () => void;
  onAutoGenerate: () => void;
  onAddMember: () => void;
  onPrint: () => void;
}

export function RosterHeader({ weekStart, memberCount, onPrev, onNext, onAutoGenerate, onAddMember, onPrint }: RosterHeaderProps) {
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);

  return (
    <header className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
            <Users className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-foreground">DutyRoster</h1>
            <p className="text-sm text-muted-foreground">DUTY ROASTER GENERATOR — Admin</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Users className="h-4 w-4" />
          <span>{memberCount} members</span>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={onPrev} className="h-9 w-9">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium min-w-[200px] text-center">
            {format(weekStart, 'd MMMM')} — {format(weekEnd, 'd MMMM yyyy')}
          </span>
          <Button variant="outline" size="icon" onClick={onNext} className="h-9 w-9">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onAutoGenerate} className="gap-1.5">
            <Sparkles className="h-4 w-4" /> Auto Generate
          </Button>
          <Button size="sm" onClick={onAddMember} className="gap-1.5 bg-accent text-accent-foreground hover:bg-accent/90">
            <UserPlus className="h-4 w-4" /> Add Member
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Share2 className="h-4 w-4" /> Share
          </Button>
          <Button variant="outline" size="sm" onClick={onPrint} className="gap-1.5">
            <Printer className="h-4 w-4" /> Print
          </Button>
        </div>
      </div>
    </header>
  );
}
