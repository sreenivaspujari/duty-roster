import { useState, useCallback, useMemo } from 'react';
import { Member, ShiftType, ShiftAssignment, SHIFT_ORDER } from '@/types/roster';
import { startOfWeek, addDays, addWeeks, subWeeks, format } from 'date-fns';

const DEFAULT_MEMBERS: Member[] = [
  { id: '1', name: 'Sarah Mitchell', role: 'Team Lead' },
  { id: '2', name: 'James Okafor', role: 'Senior Staff' },
  { id: '3', name: 'Priya Sharma', role: 'Staff' },
  { id: '4', name: 'Carlos Rivera', role: 'Staff' },
];

function generateShifts(members: Member[]): ShiftAssignment[] {
  const assignments: ShiftAssignment[] = [];
  members.forEach((member, idx) => {
    for (let day = 0; day < 7; day++) {
      const shiftIdx = (idx + day) % 4;
      assignments.push({ memberId: member.id, day, shift: SHIFT_ORDER[shiftIdx] });
    }
  });
  return assignments;
}

export function useRoster() {
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [members, setMembers] = useState<Member[]>(DEFAULT_MEMBERS);
  const [assignments, setAssignments] = useState<ShiftAssignment[]>(() => generateShifts(DEFAULT_MEMBERS));

  const weekStart = useMemo(() => startOfWeek(currentDate, { weekStartsOn: 1 }), [currentDate]);

  const days = useMemo(() => 
    Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)),
    [weekStart]
  );

  const goNextWeek = useCallback(() => setCurrentDate(d => addWeeks(d, 1)), []);
  const goPrevWeek = useCallback(() => setCurrentDate(d => subWeeks(d, 1)), []);

  const getShift = useCallback((memberId: string, day: number): ShiftType => {
    return assignments.find(a => a.memberId === memberId && a.day === day)?.shift ?? 'Off';
  }, [assignments]);

  const cycleShift = useCallback((memberId: string, day: number) => {
    setAssignments(prev => prev.map(a => {
      if (a.memberId === memberId && a.day === day) {
        const nextIdx = (SHIFT_ORDER.indexOf(a.shift) + 1) % SHIFT_ORDER.length;
        return { ...a, shift: SHIFT_ORDER[nextIdx] };
      }
      return a;
    }));
  }, []);

  const autoGenerate = useCallback(() => {
    setAssignments(generateShifts(members));
  }, [members]);

  const addMember = useCallback((name: string, role: string) => {
    const id = crypto.randomUUID();
    const newMember = { id, name, role };
    setMembers(prev => [...prev, newMember]);
    const newAssignments: ShiftAssignment[] = [];
    const offset = members.length;
    for (let day = 0; day < 7; day++) {
      newAssignments.push({ memberId: id, day, shift: SHIFT_ORDER[(offset + day) % 4] });
    }
    setAssignments(prev => [...prev, ...newAssignments]);
  }, [members]);

  const removeMember = useCallback((id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
    setAssignments(prev => prev.filter(a => a.memberId !== id));
  }, []);

  const shiftCounts = useMemo(() => {
    const counts: Record<ShiftType, number> = { Morning: 0, Afternoon: 0, Night: 0, Off: 0 };
    assignments.forEach(a => counts[a.shift]++);
    return counts;
  }, [assignments]);

  return {
    members, days, weekStart, currentDate,
    goNextWeek, goPrevWeek,
    getShift, cycleShift, autoGenerate,
    addMember, removeMember, shiftCounts,
  };
}
