import { useState } from 'react';
import { useRoster } from '@/hooks/useRoster';
import { RosterHeader } from '@/components/RosterHeader';
import { ShiftSummary } from '@/components/ShiftSummary';
import { RosterTable } from '@/components/RosterTable';
import { AddMemberDialog } from '@/components/AddMemberDialog';

const Index = () => {
  const [addOpen, setAddOpen] = useState(false);
  const roster = useRoster();

  const handlePrint = () => window.print();

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 space-y-6">
        <RosterHeader
          weekStart={roster.weekStart}
          memberCount={roster.members.length}
          onPrev={roster.goPrevWeek}
          onNext={roster.goNextWeek}
          onAutoGenerate={roster.autoGenerate}
          onAddMember={() => setAddOpen(true)}
          onPrint={handlePrint}
        />

        <ShiftSummary counts={roster.shiftCounts} />

        <RosterTable
          members={roster.members}
          days={roster.days}
          getShift={roster.getShift}
          onCycleShift={roster.cycleShift}
          onRemoveMember={roster.removeMember}
        />

        <p className="text-center text-sm text-muted-foreground">
          Click any shift cell to cycle: Morning → Afternoon → Night → Off. Use "Auto Generate" to auto-fill the week.
        </p>
      </div>

      <AddMemberDialog open={addOpen} onOpenChange={setAddOpen} onAdd={roster.addMember} />
    </div>
  );
};

export default Index;
