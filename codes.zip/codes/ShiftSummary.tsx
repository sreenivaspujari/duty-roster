import { ShiftType, SHIFT_COLORS } from '@/types/roster';
import { cn } from '@/lib/utils';

interface ShiftSummaryProps {
  counts: Record<ShiftType, number>;
}

export function ShiftSummary({ counts }: ShiftSummaryProps) {
  const items: ShiftType[] = ['Morning', 'Afternoon', 'Night', 'Off'];
  return (
    <div className="flex flex-wrap items-center gap-3">
      {items.map(shift => (
        <div key={shift} className="flex items-center gap-1.5">
          <span className={cn('px-2.5 py-0.5 rounded-full text-xs font-semibold', SHIFT_COLORS[shift])}>
            {shift}
          </span>
          <span className="text-sm text-muted-foreground">
            <span className="font-bold text-foreground">{counts[shift]}</span> shifts
          </span>
        </div>
      ))}
    </div>
  );
}
